import xbmcaddon

MainBase = 'https://pastebin.com/raw/WpDQgpGi'
addon = xbmcaddon.Addon('plugin.video.Rising.Tides')