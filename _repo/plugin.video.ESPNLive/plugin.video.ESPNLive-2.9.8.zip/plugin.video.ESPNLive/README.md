plugin.video.espn_3
===================

1.  `make_zip.sh` - Makes a zip file for the custom repository, assumes that repo.kodi-addons is also checked out
2.  `make_repo-plugins.sh` - Copies the addon to repo-plugins in order to perform a release for Kodi

Fork of original espn3 addon by bluecop and locomot1f.
Credit to eracknaphobia from plugin.video.nbcsnliveextra.
Credit to Kodi forum members for helping with debugging (http://forum.kodi.tv/showthread.php?tid=230418,
siuside, OTinley, lionsnob, and others)

Watch full live streaming sporting events and replays on ESPN 3 (and premium channels with cable provider), including football, baseball, cricket, soccer, and basketball events.
