import xbmcaddon, util

addon = xbmcaddon.Addon('plugin.video.SaudiQuranTV.en')

xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/?action=play_video&videoid=Yu2lmo3TrfY)')