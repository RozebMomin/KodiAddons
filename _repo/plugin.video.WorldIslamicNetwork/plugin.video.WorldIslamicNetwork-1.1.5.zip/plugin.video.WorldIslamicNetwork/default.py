import xbmcaddon, util
import subprocess
from subprocess import call
import json
import os

#https://www.youtube.com/watch?v=acWnaZnoGkU

addon = xbmcaddon.Addon('plugin.video.WorldIslamicNetwork')

xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/play/?video_id=acWnaZnoGkU)')

#acWnaZnoGkU