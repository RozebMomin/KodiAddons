from resources.odict.pyodict import odict
